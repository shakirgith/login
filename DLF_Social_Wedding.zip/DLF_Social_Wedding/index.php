<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>AR Celebrate</title>
        <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon" />
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    </head>
    <body>
        <div class="main-wrapper">
            <!-- <img class="samsung-logo" src="assets/images/logo.png" alt="Logo"> -->
            <div class="my-container">
              <!-- <h4>Take your phone towards the poster<span>and press OK</span></h4> -->
                <div class="login-form">
                    <img class="img-fluid" src="assets/images/logo.png" alt="Samsung Logo">
                    <!-- <div class="register-button">
                        <button type="submit" class="login_btn">OK</button>
                    </div> -->
                </div>
            </div>
        </div>
        <script type="text/javascript" src="assets/js/jquery.min.js"></script>>
        <script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
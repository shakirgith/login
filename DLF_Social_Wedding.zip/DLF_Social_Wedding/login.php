<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>AR Celebrate</title>
        <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon" />
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    </head>
    <body>
        <div class="login-wrapper">
            <div class="my-container">
            <!-- <h4>Come experience the revolutionary <span>future and get a chance to win a prize</span></h4> -->
             <div class="homelogo">
                <img class="img-fluid" src="assets/images/logo.png" alt="Logo">
                </div>
                <div class="login-form">
               
                  

                    <form action="#" method="post" name="register">
                        <div class="register-section">
                            <!-- <div class="form-group">
                                <input type="text" class="form-control" name="name" placeholder="Name">         
                                
                            </div> -->
                            <div class="form-group">
                                <input type="text" class="form-control" name="mobile" placeholder="Mobile">
                                
                            </div>
                            <div class="register-button">
                                <button type="submit" class="login_btn">ENTER</button>
                                <span class="flowers"></span>
                            </div>
                            
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script type="text/javascript" src="assets/js/jquery.min.js"></script>
        <script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
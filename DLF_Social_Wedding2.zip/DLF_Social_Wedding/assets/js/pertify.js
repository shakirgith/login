var ajaxRequested = false;
$(document).ready(function() {

	$(document).on('submit','.myajaxss_form',function(event){
	
	var submitBtn = $(this).find('button[type="submit"]');
	submitBtn.attr('disabled','disabled');
	var purl=$(this).attr('action');
	var $this = $(this).closest('form');
	var formid =$(this).attr('id');
	var formClass =$(this).attr('class');
	var loadingHTML = ' <i class="fas fa-circle-notch fa-spin fa-1x fa-fw submit_loader"></i>'
	submitBtn.append(loadingHTML);
	if(!formid)
	formid = formClass;
	window.ajaxRequested = true;
	$($this).find('.form-group').removeClass('has-error');
	$($this).find('.help-block').hide();
	thisform = $this;
	
	$(this).ajaxSubmit({		
		headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
					url: purl,
					dataType: 'json',
					success: function(response){
					
						checkTosterResponsecheck(response);
						response.formid = formid;
						submitBtn.removeAttr('disabled');
						submitBtn.find('.fa-spin').remove();
						window.ajaxRequested = false;
			
						if(response.redirectURL)
							
							window.location.href=response.redirectURL;
						if(response.scrollToThisForm)
							scrollToElementcheck('#'+formid,1000);
						if(response.selfReload)
							window.location.reload();
						if(response.resetForm)
							$($this).resetForm();
						if(response.callBackFunction)
							callBackMefunction(response.callBackFunction,response);
					},
					error:function(response){
						submitBtn.removeAttr('disabled'); 
						submitBtn.find('.fa-spin').remove();
					}
				});
	return false;
	});
});
function callBackMefunction(functionName,data)
{
	window[functionName](data);
}
function scrollToElementcheck(element,speed)
{
	$('html, body').animate({scrollTop:$(element).position().top + 10},speed);
}
function checkTosterResponsecheck(data)
{
	if(data)
	{
	  if(data.message)
	  {
	    if(data.success)
	    {
            $.toast({
                heading: 'Success',
                text: data.message,
                icon: 'success',
                loader: true,        
                loaderBg: '#9EC600',  
                showHideTransition: 'fade'
            });
	    }
	    else
	    {
	       $.toast({
                heading: 'Error',
                text: data.message,
                icon: 'error',
                loader: true,       
                loaderBg: 'red', 
                showHideTransition: 'fade'
            });
	    }
	  }
	}
}